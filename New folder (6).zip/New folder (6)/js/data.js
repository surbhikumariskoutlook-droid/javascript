// Central Database for CosmoBites: Intergalactic Dining Portal
const RESTAURANTS_DATA = [
  {
    id: "apollo",
    name: "Apollo Trattoria",
    tagline: "Authentic Italian Gastronomy Infused with Orbital Precision",
    cuisine: "Italian & Mediterranean",
    rating: 4.9,
    reviewCount: 342,
    deliveryTime: "25-35 min",
    priceRange: "$$$",
    bannerImage: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1400&q=80",
    themeColor: "#f59e0b",
    badge: "Michelin Orbit Star",
    contact: {
      phone: "+1 (800) 555-APOLLO",
      hotline: "+1 (888) 782-7632 (STAR-MED)",
      email: "command@apollotrattoria.space",
      address: "Station Sector 4A, Horizon Deck, Lunar Base Alpha",
      hours: "11:00 AM - 11:00 PM UTC"
    },
    astronaut: {
      name: "Commander Marco 'Starfall' Rossi",
      role: "Head Executive Chef & ISS Artemis Flight Specialist",
      rank: "Lieutenant Commander (Ret. ESA/NASA)",
      avatar: "https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=600&q=80",
      quote: "Cooking at 400km above Earth taught me that gravity can't hold back true flavor. Every pasta swirl carries the essence of the stars.",
      missions: "Artemis III, ISS Expedition 64 & 68",
      specialty: "Zero-G Truffle Emulsions & Wood-Fired Orbital Pizza",
      commsChannel: "VHF 145.800 MHz (Sub-space Comms)"
    },
    dishes: [
      {
        id: "ap-1",
        name: "Stardust Truffle Tagliatelle",
        category: "Mains",
        price: 24.50,
        calories: "580 kcal",
        image: "https://images.unsplash.com/photo-1556760544-74068565f05c?auto=format&fit=crop&w=600&q=80",
        description: "Hand-rolled ribbons of pasta tossed in black Piedmont truffle cream, 36-month Parmigiano Reggiano, and finished with 24k edible gold flakes.",
        badge: "Chef's Signature",
        tags: ["Vegetarian", "Bestseller"]
      },
      {
        id: "ap-2",
        name: "Supernova Margherita Pizza",
        category: "Mains",
        price: 19.99,
        calories: "720 kcal",
        image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=600&q=80",
        description: "San Marzano volcanic tomatoes, creamy Fior di Latte mozzarella, orbital-grown micro-basil, cold-pressed Sicilian olive oil on a 48h sourdough crust.",
        badge: "Wood-Fired",
        tags: ["Classic", "Vegetarian"]
      },
      {
        id: "ap-3",
        name: "Lunar Burrata al Pesto",
        category: "Appetizers",
        price: 16.50,
        calories: "410 kcal",
        image: "https://images.unsplash.com/photo-1592417817098-8f3d6910985c?auto=format&fit=crop&w=600&q=80",
        description: "Velvety Puglia burrata sphere resting on wild rocket, blistered heirloom cherry tomatoes, roasted pine nuts, and aged Modena balsamic pearls.",
        badge: "Popular",
        tags: ["Vegetarian", "Gluten-Free Option"]
      },
      {
        id: "ap-4",
        name: "Galactic Ossobuco alla Milanese",
        category: "Mains",
        price: 34.00,
        calories: "820 kcal",
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
        description: "Slow-braised cross-cut veal shank in white wine and mirepoix, accompanied by saffron-infused carnaroli risotto and fresh citrus gremolata.",
        badge: "Hearty",
        tags: ["Gluten-Free", "Rich"]
      },
      {
        id: "ap-5",
        name: "Cosmic Calamari Fritti",
        category: "Appetizers",
        price: 17.50,
        calories: "460 kcal",
        image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80",
        description: "Crispy flash-fried Adriatic squid rings and tentacles served with charred lemon wedges and black garlic aioli.",
        badge: "Crispy",
        tags: ["Seafood"]
      },
      {
        id: "ap-6",
        name: "Nebula Lobster Ravioli",
        category: "Mains",
        price: 29.50,
        calories: "640 kcal",
        image: "https://images.unsplash.com/photo-1587740908075-9e245070dfaa?auto=format&fit=crop&w=600&q=80",
        description: "Delicate pasta pillows filled with butter-poached Maine lobster and ricotta, swimming in a velvety saffron-tarragon bisque.",
        badge: "Luxury",
        tags: ["Seafood", "Signature"]
      },
      {
        id: "ap-7",
        name: "Prosciutto & Fig Crostini",
        category: "Appetizers",
        price: 15.00,
        calories: "320 kcal",
        image: "https://images.unsplash.com/photo-1506280754576-f6fa8a873550?auto=format&fit=crop&w=600&q=80",
        description: "Toasted artisanal ciabatta crowned with Parma prosciutto, whipped gorgonzola, fresh Mission figs, and hot orbital honey.",
        badge: "Artisanal",
        tags: ["Gourmet"]
      },
      {
        id: "ap-8",
        name: "Zero-G Wild Mushroom Risotto",
        category: "Mains",
        price: 22.00,
        calories: "510 kcal",
        image: "https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=600&q=80",
        description: "Creamy Acquerello rice infused with foraged chanterelles, porcini broth, fresh thyme, and cultured alpine butter.",
        badge: "Earth-Grown",
        tags: ["Vegetarian", "Gluten-Free"]
      },
      {
        id: "ap-9",
        name: "Sicilian Arancini di Riso",
        category: "Appetizers",
        price: 14.50,
        calories: "390 kcal",
        image: "https://images.unsplash.com/photo-1541529086526-db283c563270?auto=format&fit=crop&w=600&q=80",
        description: "Golden fried saffron rice spheres stuffed with braised ragù bolognese and gooey scamorza cheese, with spicy marinara dip.",
        badge: "Crispy",
        tags: ["Traditional"]
      },
      {
        id: "ap-10",
        name: "Orbit-Roasted Branzino",
        category: "Mains",
        price: 31.00,
        calories: "490 kcal",
        image: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80",
        description: "Whole Mediterranean sea bass filet roasted with rosemary sea salt, caper berries, crushed fingerling potatoes, and lemon reduction.",
        badge: "Fresh Catch",
        tags: ["Healthy", "Gluten-Free"]
      },
      {
        id: "ap-11",
        name: "Astronaut Gnocchi Gorgonzola",
        category: "Mains",
        price: 21.00,
        calories: "630 kcal",
        image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80",
        description: "Pillow-soft potato dumplings enveloped in sweet gorgonzola dolce cream, toasted walnuts, and fresh pear compote.",
        badge: "Comfort",
        tags: ["Vegetarian"]
      },
      {
        id: "ap-12",
        name: "Starfall Tiramisù Classico",
        category: "Desserts",
        price: 11.50,
        calories: "380 kcal",
        image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=600&q=80",
        description: "Espresso-soaked Savoiardi biscuits layered with fluffy mascarpone sabayon, dusted with Valrhona Dutch cocoa and dark chocolate shavings.",
        badge: "Must Try",
        tags: ["Dessert", "Vegetarian"]
      },
      {
        id: "ap-13",
        name: "Cannoli Siciliani Orbitali",
        category: "Desserts",
        price: 9.50,
        calories: "340 kcal",
        image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=600&q=80",
        description: "Crisp cinnamon pastry tubes filled with sweetened sheep ricotta, Bronte pistachios, and candied orange peel zest.",
        badge: "Sweet",
        tags: ["Dessert"]
      },
      {
        id: "ap-14",
        name: "Solar Limoncello Panna Cotta",
        category: "Desserts",
        price: 10.00,
        calories: "290 kcal",
        image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80",
        description: "Silky Madagascar vanilla bean cream with tangy Amalfi limoncello gelée and fresh blackberry coulis.",
        badge: "Refreshing",
        tags: ["Dessert", "Gluten-Free"]
      },
      {
        id: "ap-15",
        name: "Cosmic Negroni Spumante",
        category: "Beverages",
        price: 14.00,
        calories: "180 kcal",
        image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
        description: "Botanical dry gin, Campari bitter, Carpano Antica vermouth, and sparkling Prosecco misted with orange vapor.",
        badge: "Cocktail",
        tags: ["Alcoholic", "Signature Drink"]
      },
      {
        id: "ap-16",
        name: "Zero-G Espresso Macchiato",
        category: "Beverages",
        price: 5.50,
        calories: "45 kcal",
        image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80",
        description: "Double extraction ISSpresso roast capped with velvety micro-foam, designed for anti-spill zero-gravity sipping.",
        badge: "Energizer",
        tags: ["Coffee", "Hot"]
      },
      {
        id: "ap-17",
        name: "Aperol Meteor Spritz",
        category: "Beverages",
        price: 13.00,
        calories: "160 kcal",
        image: "https://images.unsplash.com/photo-1560512823-829485b8bf24?auto=format&fit=crop&w=600&q=80",
        description: "Vibrant Aperol, Valdobbiadene Prosecco DOCG, mineral soda splash, garnished with dehydrated solar orange wheel.",
        badge: "Sparkling",
        tags: ["Cocktail"]
      },
      {
        id: "ap-18",
        name: "Rosemary Focaccia Genovese",
        category: "Appetizers",
        price: 8.50,
        calories: "280 kcal",
        image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",
        description: "Crisp-bottomed, pillowy olive oil bread sprinkled with Maldon sea salt crystals and fresh garden rosemary.",
        badge: "Fresh Baked",
        tags: ["Vegan", "Warm"]
      }
    ],
    reviews: [
      {
        user: "Dr. Sarah Chen",
        rating: 5,
        date: "Yesterday",
        comment: "The Stardust Truffle Tagliatelle is completely out of this world! Chef Marco Rossi personally came over via comms to ask about our meal. 10/10 dining experience.",
        verified: true
      },
      {
        user: "Capt. Liam Gallagher",
        rating: 5,
        date: "3 days ago",
        comment: "Best wood-fired pizza on this side of the Milky Way. Crisp crust, fresh ingredients, and the delivery arrived in 20 minutes piping hot in thermal orbital pods.",
        verified: true
      },
      {
        user: "Amara Patel",
        rating: 4,
        date: "1 week ago",
        comment: "Tiramisu was heavenly! Loved the astronaut notes in the packaging and the prompt customer care hotline.",
        verified: true
      }
    ]
  },
  {
    id: "nebula",
    name: "Nebula Smokehouse & BBQ",
    tagline: "Slow-Smoked Meats, Fiery Gravity Glazes & Mars-Roast Cuts",
    cuisine: "Galactic American BBQ & Grill",
    rating: 4.8,
    reviewCount: 418,
    deliveryTime: "30-40 min",
    priceRange: "$$",
    bannerImage: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1400&q=80",
    themeColor: "#ef4444",
    badge: "Pitmaster Champion",
    contact: {
      phone: "+1 (800) 555-SMOKE",
      hotline: "+1 (888) 632-8521 (NEBULA-BBQ)",
      email: "pitmaster@nebulabbq.space",
      address: "Hangar Bay 9, Red Dune Boulevard, Mars Outpost One",
      hours: "12:00 PM - 12:00 AM UTC"
    },
    astronaut: {
      name: "Captain Elena 'Blaze' Vance",
      role: "Commander of Deep Space Habitation & Thermal Grill Master",
      rank: "Colonel & Propulsion Engineer (US Space Command)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
      quote: "When you manage rocket propulsion temperatures of 3,000°F, low-and-slow hickory smoking at 225°F is second nature.",
      missions: "Mars Expedition II, Deep Space Gateway Flight Director",
      specialty: "Mesquite-Smoked Wagyu Brisket & Meteor Glazes",
      commsChannel: "UHF 437.525 MHz (Thermal Grill Channel)"
    },
    dishes: [
      {
        id: "nb-1",
        name: "Mars Rover 16-Hour Smoked Brisket",
        category: "Mains",
        price: 28.99,
        calories: "890 kcal",
        image: "https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80",
        description: "Prime black Angus brisket smoked for 16 hours over aged hickory and post oak, crusted in cracked black pepper and dark molasses glaze.",
        badge: "Pitmaster Special",
        tags: ["Bestseller", "Gluten-Free"]
      },
      {
        id: "nb-2",
        name: "Meteor Glazed Baby Back Ribs",
        category: "Mains",
        price: 26.50,
        calories: "920 kcal",
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
        description: "Fall-off-the-bone tender rack basted in chipotle bourbon BBQ sauce with pickled jalapeños and crispy sweet potato crisps.",
        badge: "Crowd Favorite",
        tags: ["Smoked"]
      },
      {
        id: "nb-3",
        name: "Supercharged Pulled Pork Sando",
        category: "Mains",
        price: 16.50,
        calories: "670 kcal",
        image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
        description: "Slow-roasted pork shoulder tossed in tangy Carolina vinegar sauce, topped with crunchy purple slaw on toasted brioche.",
        badge: "Juicy",
        tags: ["Sandwich"]
      },
      {
        id: "nb-4",
        name: "Asteroid Crispy Hot Wings (12 pcs)",
        category: "Appetizers",
        price: 15.99,
        calories: "740 kcal",
        image: "https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format&fit=crop&w=600&q=80",
        description: "Double-crunch jumbo chicken wings bathed in ghost pepper honey glaze, served with blue cheese ranch and celery batons.",
        badge: "Spicy 🔥🔥",
        tags: ["Crispy", "Popular"]
      },
      {
        id: "nb-5",
        name: "Zero-G Truffle Mac & Cheese",
        category: "Appetizers",
        price: 12.50,
        calories: "540 kcal",
        image: "https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=600&q=80",
        description: "Cavatappi pasta drenched in aged cheddar, gruyère, and gouda cheese sauce with roasted garlic panko crust.",
        badge: "Cheesy",
        tags: ["Vegetarian"]
      },
      {
        id: "nb-6",
        name: "Solar Flares Jalapeño Poppers",
        category: "Appetizers",
        price: 11.00,
        calories: "430 kcal",
        image: "https://images.unsplash.com/photo-1534939561126-855b8675edd7?auto=format&fit=crop&w=600&q=80",
        description: "Fresh jalapeño peppers stuffed with herbed cream cheese and smoked bacon lardons, crisped to golden perfection.",
        badge: "Spicy",
        tags: ["Finger Food"]
      },
      {
        id: "nb-7",
        name: "Galactic Cowboy Ribeye Steak (16 oz)",
        category: "Mains",
        price: 39.50,
        calories: "960 kcal",
        image: "https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=600&q=80",
        description: "USDA Prime bone-in ribeye seared on 800° cast iron, basted with rosemary bone marrow butter and roasted garlic cloves.",
        badge: "Prime Cut",
        tags: ["High Protein", "Gluten-Free"]
      },
      {
        id: "nb-8",
        name: "Cosmic Smoked Turkey Breast",
        category: "Mains",
        price: 21.00,
        calories: "490 kcal",
        image: "https://images.unsplash.com/photo-1514944298352-257a0701ec6a?auto=format&fit=crop&w=600&q=80",
        description: "Juicy herb-rubbed farm turkey breast smoked over applewood, carved thick with cranberry peppercorn relish.",
        badge: "Lean & Healthy",
        tags: ["Gluten-Free", "Low Carb"]
      },
      {
        id: "nb-9",
        name: "Loaded Orbital Potato Skins",
        category: "Appetizers",
        price: 10.50,
        calories: "480 kcal",
        image: "https://images.unsplash.com/photo-1576107232684-1279f3908594?auto=format&fit=crop&w=600&q=80",
        description: "Crispy Idaho russets baked with sharp cheddar, smoked brisket ends, sour cream drizzle, and scallions.",
        badge: "Snack",
        tags: ["Comfort"]
      },
      {
        id: "nb-10",
        name: "Deep Space Cornbread Skillet",
        category: "Appetizers",
        price: 8.00,
        calories: "340 kcal",
        image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",
        description: "Golden honey butter cast iron cornbread baked fresh per order, topped with whipped chili butter.",
        badge: "Sweet & Savory",
        tags: ["Vegetarian"]
      },
      {
        id: "nb-11",
        name: "Nebula Bourbon Pecan Pie",
        category: "Desserts",
        price: 9.50,
        calories: "510 kcal",
        image: "https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=600&q=80",
        description: "Southern roasted pecans encased in Kentucky bourbon caramel inside a flaky butter crust, served warm with vanilla cream.",
        badge: "Classic",
        tags: ["Dessert"]
      },
      {
        id: "nb-12",
        name: "Charred S'mores Campfire Sundae",
        category: "Desserts",
        price: 10.00,
        calories: "560 kcal",
        image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80",
        description: "Dark chocolate gelato, graham cracker dust, blowtorched marshmallow fluff, and warm fudge sauce.",
        badge: "Sweet Bomb",
        tags: ["Dessert"]
      },
      {
        id: "nb-13",
        name: "Smoked Cherry Old Fashioned",
        category: "Beverages",
        price: 14.50,
        calories: "190 kcal",
        image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=600&q=80",
        description: "Woodford Reserve Bourbon, spiced cherry bitters, expressed orange peel, presented under a cloche filled with aromatic oak smoke.",
        badge: "Smoky Cocktail",
        tags: ["Alcoholic"]
      },
      {
        id: "nb-14",
        name: "Cosmic Sweet Peach Iced Tea",
        category: "Beverages",
        price: 4.99,
        calories: "120 kcal",
        image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&q=80",
        description: "Cold-brewed Ceylon black tea infused with ripe Georgia peach nectar and fresh garden mint leaves.",
        badge: "Refreshing",
        tags: ["Non-Alcoholic"]
      },
      {
        id: "nb-15",
        name: "Draft Rocket Fuel Stout",
        category: "Beverages",
        price: 8.50,
        calories: "240 kcal",
        image: "https://images.unsplash.com/photo-1608270546057-0a4e768b3fdc?auto=format&fit=crop&w=600&q=80",
        description: "Nitro-infused imperial dark stout brewed with roasted barley, Venezuelan cacao nibs, and cold drip coffee.",
        badge: "Craft Beer",
        tags: ["Alcoholic"]
      },
      {
        id: "nb-16",
        name: "Tangy Red Planet Apple Cider",
        category: "Beverages",
        price: 5.50,
        calories: "140 kcal",
        image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80",
        description: "Spiced honeycrisp apple cider served steaming hot or over glacier ice cubes with cinnamon quills.",
        badge: "Cozy",
        tags: ["Non-Alcoholic"]
      }
    ],
    reviews: [
      {
        user: "Marcus Brody",
        rating: 5,
        date: "2 days ago",
        comment: "Captain Elena's 16-hour smoked brisket is pure bliss. The smoke ring on the meat is museum-worthy. Best BBQ across the star system!",
        verified: true
      },
      {
        user: "Lieutenant Jessica Wu",
        rating: 5,
        date: "5 days ago",
        comment: "The bourbon old fashioned arrived in an insulated smoke flask, completely mindblowing. Wings had the exact kick I craved.",
        verified: true
      },
      {
        user: "Tariq Mansoor",
        rating: 4,
        date: "2 weeks ago",
        comment: "Ribs literally melted off the bone. Support hotline helped me change my delivery address in under 30 seconds when I made a mistake.",
        verified: true
      }
    ]
  },
  {
    id: "lunar-zen",
    name: "Lunar Zen Fusion",
    tagline: "Serene Pan-Asian Craft, Zero-G Ramen & Bio-Dome Fresh Sushi",
    cuisine: "Japanese, Pan-Asian & Ramen Bar",
    rating: 4.95,
    reviewCount: 512,
    deliveryTime: "20-30 min",
    priceRange: "$$$",
    bannerImage: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1400&q=80",
    themeColor: "#06b6d4",
    badge: "Omakase Excellence",
    contact: {
      phone: "+1 (800) 555-RAMEN",
      hotline: "+1 (888) 936-7874 (ZEN-SUSHI)",
      email: "sensei@lunarzen.space",
      address: "Peace Garden Module 12, Celestial Ring Station",
      hours: "11:30 AM - 10:30 PM UTC"
    },
    astronaut: {
      name: "Dr. Kenji 'Supernova' Sato",
      role: "Lead Astrobiologist, Hydroponic Botanist & Master Sushi Chef",
      rank: "Mission Commander (JAXA / Orbital Science Consortium)",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80",
      quote: "Balancing nutrients for astronauts in deep space taught me the delicate harmony of umami, texture, and mindfulness.",
      missions: "Kibo Module Expedition 59, Lunar Gateway Agronomy Pilot",
      specialty: "Hydro-grown Wasabi, 48-Hour Tonkotsu & Bluefin Otoro",
      commsChannel: "SHF 5.840 GHz (Zen Comms Matrix)"
    },
    dishes: [
      {
        id: "lz-1",
        name: "Supernova Tonkotsu Black Garlic Ramen",
        category: "Mains",
        price: 21.50,
        calories: "780 kcal",
        image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80",
        description: "Rich 24-hour simmered pork bone broth, springy handmade alkaline noodles, slow-braised chashu pork belly, molten nitamago egg, and fragrant black garlic oil.",
        badge: "Chef's Masterpiece",
        tags: ["Bestseller", "Comfort Food"]
      },
      {
        id: "lz-2",
        name: "Zero-G Bluefin Otoro Nigiri (4 pcs)",
        category: "Appetizers",
        price: 26.00,
        calories: "320 kcal",
        image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=600&q=80",
        description: "Fatty bluefin tuna belly torched with nikiri soy glaze, topped with fresh space-station hydroponic wasabi and Siberian caviar.",
        badge: "Ultra Premium",
        tags: ["Raw", "Seafood"]
      },
      {
        id: "lz-3",
        name: "Cosmic Dragon Specialty Roll (8 pcs)",
        category: "Mains",
        price: 19.50,
        calories: "510 kcal",
        image: "https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?auto=format&fit=crop&w=600&q=80",
        description: "Crispy tempura prawn and cucumber wrapped with thinly sliced avocado, BBQ freshwater unagi, tobiko, and spicy unagi glaze.",
        badge: "Signature Roll",
        tags: ["Seafood", "Popular"]
      },
      {
        id: "lz-4",
        name: "Lunar Truffle Edamame",
        category: "Appetizers",
        price: 9.00,
        calories: "190 kcal",
        image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
        description: "Steamed organic young soybeans tossed in white truffle oil, roasted garlic chips, and Maldon sea salt flakes.",
        badge: "Healthy",
        tags: ["Vegan", "Gluten-Free"]
      },
      {
        id: "lz-5",
        name: "Kurobuta Pork Gyoza (6 pcs)",
        category: "Appetizers",
        price: 12.00,
        calories: "360 kcal",
        image: "https://images.unsplash.com/photo-1498654896293-37aacf113fd9?auto=format&fit=crop&w=600&q=80",
        description: "Pan-crisped Japanese dumplings stuffed with seasoned Berkshire pork, scallions, and shiitake, served with chili rayu ponzu.",
        badge: "Crispy Skirt",
        tags: ["Crowd Favorite"]
      },
      {
        id: "lz-6",
        name: "Miso-Glazed Black Cod (Gindara)",
        category: "Mains",
        price: 36.00,
        calories: "540 kcal",
        image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80",
        description: "Sustainably caught Alaskan sablefish marinated for 72 hours in sweet saikyo miso and mirin, caramelized over white binchotan charcoal.",
        badge: "Michelin Style",
        tags: ["Pescatarian", "Gluten-Free"]
      },
      {
        id: "lz-7",
        name: "A5 Miyazaki Wagyu Donburi",
        category: "Mains",
        price: 38.50,
        calories: "740 kcal",
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
        description: "Seared A5 Wagyu beef strips served over Koshihikari rice, with onsen tamago egg, shaved summer truffles, and tare reduction.",
        badge: "Luxury",
        tags: ["A5 Wagyu"]
      },
      {
        id: "lz-8",
        name: "Spicy Volcano Hamachi Roll",
        category: "Mains",
        price: 18.50,
        calories: "480 kcal",
        image: "https://images.unsplash.com/photo-1553621042-f6e147245754?auto=format&fit=crop&w=600&q=80",
        description: "Yellowtail, jalapeño, and cilantro roll topped with spicy lump crab, sriracha aioli, and crispy shallots.",
        badge: "Spicy 🔥",
        tags: ["Seafood"]
      },
      {
        id: "lz-9",
        name: "Hydroponic Mushroom Bao Buns (3 pcs)",
        category: "Appetizers",
        price: 13.50,
        calories: "380 kcal",
        image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80",
        description: "Cloud-soft steamed lotus buns filled with glazed king oyster mushrooms, pickled cucumber, crushed peanuts, and hoisin.",
        badge: "Steamed",
        tags: ["Vegetarian"]
      },
      {
        id: "lz-10",
        name: "Zen Matcha Lava Cake",
        category: "Desserts",
        price: 11.00,
        calories: "420 kcal",
        image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",
        description: "Warm molten ceremonial grade Uji matcha cake with a flowing green tea ganache center, paired with black sesame ice cream.",
        badge: "Decadent",
        tags: ["Dessert", "Vegetarian"]
      },
      {
        id: "lz-11",
        name: "Tokyo Mochi Trio (Ice Cream)",
        category: "Desserts",
        price: 8.50,
        calories: "280 kcal",
        image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80",
        description: "Chewy sweet rice cake filled with artisan mango, yuzu, and adzuki bean gelato.",
        badge: "Gluten-Free",
        tags: ["Dessert"]
      },
      {
        id: "lz-12",
        name: "Smoked Yuzu Highball",
        category: "Beverages",
        price: 13.50,
        calories: "140 kcal",
        image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=600&q=80",
        description: "Japanese blended whisky, fresh yuzu juice, sparkling mineral water, served over hand-carved crystal diamond ice with thyme sprig.",
        badge: "Signature",
        tags: ["Cocktail"]
      },
      {
        id: "lz-13",
        name: "Organic Gyokuro Imperial Green Tea",
        category: "Beverages",
        price: 6.00,
        calories: "0 kcal",
        image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80",
        description: "Shade-grown single-estate shaded green tea brewed at precise 60°C for deep, sweet vegetal umami notes.",
        badge: "Soothing",
        tags: ["Hot Tea", "Zero Calorie"]
      },
      {
        id: "lz-14",
        name: "Sparkling Lychee Nebula Boba",
        category: "Beverages",
        price: 7.50,
        calories: "210 kcal",
        image: "https://images.unsplash.com/photo-1558857563-b372c3d52c58?auto=format&fit=crop&w=600&q=80",
        description: "Fragrant lychee fruit nectar, butterfly pea flower color-changing tea, and popping brown sugar pearls.",
        badge: "Color-Changing",
        tags: ["Mocktail", "Fun"]
      },
      {
        id: "lz-15",
        name: "Sake Flight: Junmai Daiginjo Selection",
        category: "Beverages",
        price: 18.00,
        calories: "220 kcal",
        image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
        description: "Tasting flight of three award-winning Japanese sakes: Dassai 23, Kubota Manju, and Dewazakura Dewasansan.",
        badge: "Premium Sake",
        tags: ["Alcoholic"]
      }
    ],
    reviews: [
      {
        user: "Kenjiro Takahashi",
        rating: 5,
        date: "3 days ago",
        comment: "As someone who lived in Tokyo for 20 years, Dr. Sato's Tonkotsu broth is genuine mastery. The depth of flavor is unmatched. The packaging is completely vacuum-sealed and fresh.",
        verified: true
      },
      {
        user: "Commander Maya Lin",
        rating: 5,
        date: "1 week ago",
        comment: "The Otoro Nigiri melted in my mouth. We ordered during a shift change and the order came faster than our shuttle dock cycle! Phenomenal support team too.",
        verified: true
      },
      {
        user: "Samuel O'Connor",
        rating: 5,
        date: "2 weeks ago",
        comment: "Matcha lava cake is decadent. Great UI, easy ordering, and tracking the astronaut chef in real-time is a blast.",
        verified: true
      }
    ]
  },
  {
    id: "solaris",
    name: "Solaris Taquería & Cantina",
    tagline: "Vibrant Zero-G Mexican Street Flavors, Fire-Salsa & Agave Oasis",
    cuisine: "Mexican & Latin Street Food",
    rating: 4.85,
    reviewCount: 389,
    deliveryTime: "15-25 min",
    priceRange: "$$",
    bannerImage: "https://images.unsplash.com/photo-1504544750208-dc0358e5397c?auto=format&fit=crop&w=1400&q=80",
    themeColor: "#10b981",
    badge: "Street Food Legend",
    contact: {
      phone: "+1 (800) 555-TACOS",
      hotline: "+1 (888) 765-2747 (SOLAR-TACO)",
      email: "fiesta@solaristaqueria.space",
      address: "Solar Prominence Promenade, Habitat 7, Lunar Gateway",
      hours: "10:00 AM - 01:00 AM UTC"
    },
    astronaut: {
      name: "Specialist Mateo 'Cosmo' Cruz",
      role: "EVA Mobility Expert & Cosmic Taquero Supreme",
      rank: "Senior Astronaut Specialist (Agencia Espacial / NASA)",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80",
      quote: "Astronaut food used to be bland paste. When I smuggled authentic Mexican chilies to the station, the entire crew cheered. Flavor is morale!",
      missions: "Crew Dragon Expedition 7, Deep Orbit EVAs",
      specialty: "Birria Quesatacos, Charred Habanero Salsa & Agave Crafting",
      commsChannel: "VHF 146.520 MHz (Fiesta Frequency)"
    },
    dishes: [
      {
        id: "so-1",
        name: "Zero-G Birria Quesatacos (3 pcs)",
        category: "Mains",
        price: 18.99,
        calories: "720 kcal",
        image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=600&q=80",
        description: "Crispy grilled corn tortillas soaked in chili broth, packed with slow-braised beef shank, melted Oaxaca cheese, cilantro, onions, and rich dipping consommé.",
        badge: "Bestseller",
        tags: ["Savory", "Gluten-Free"]
      },
      {
        id: "so-2",
        name: "Solar Flare Al Pastor Tacos (3 pcs)",
        category: "Mains",
        price: 16.50,
        calories: "590 kcal",
        image: "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?auto=format&fit=crop&w=600&q=80",
        description: "Achiote-marinated pork shoulder shaved from a vertical spit, topped with caramelized roasted pineapple, white onion, cilantro, and avocado crema.",
        badge: "Traditional",
        tags: ["Flavor Explosion"]
      },
      {
        id: "so-3",
        name: "Galactic Guacamole & Warm Chips",
        category: "Appetizers",
        price: 11.50,
        calories: "390 kcal",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80",
        description: "Hand-mashed Michoacán avocados, lime juice, sea salt, serrano peppers, cilantro, pomegranate arils, and warm fresh corn totopos.",
        badge: "Freshly Mashed",
        tags: ["Vegan", "Gluten-Free"]
      },
      {
        id: "so-4",
        name: "Cosmic Carne Asada Burrito Gigante",
        category: "Mains",
        price: 17.50,
        calories: "850 kcal",
        image: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=600&q=80",
        description: "Huge flour tortilla loaded with grilled flank steak, pinto beans, Mexican rice, guacamole, pico de gallo, and spicy salsa verde.",
        badge: "Massive Portion",
        tags: ["Hearty"]
      },
      {
        id: "so-5",
        name: "Baja Blast Crispy Fish Tacos (3 pcs)",
        category: "Mains",
        price: 17.00,
        calories: "530 kcal",
        image: "https://images.unsplash.com/photo-1512838243191-e81e88cc8912?auto=format&fit=crop&w=600&q=80",
        description: "Beer-battered fresh Pacific cod on warm tortillas with shredded cabbage, chipotle crema, and tangy mango pico.",
        badge: "Crispy",
        tags: ["Seafood"]
      },
      {
        id: "so-6",
        name: "Elote Callejero 'Starlight' Corn",
        category: "Appetizers",
        price: 8.50,
        calories: "280 kcal",
        image: "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=600&q=80",
        description: "Char-grilled street corn on the cob brushed with Mexican crema, cotija cheese, Tajín chili lime seasoning, and cilantro.",
        badge: "Street Classic",
        tags: ["Vegetarian"]
      },
      {
        id: "so-7",
        name: "Chorizo Fundido con Queso",
        category: "Appetizers",
        price: 13.00,
        calories: "620 kcal",
        image: "https://images.unsplash.com/photo-1541529086526-db283c563270?auto=format&fit=crop&w=600&q=80",
        description: "Bubbling skillet of melted Chihuahua and Asadero cheese crowned with spicy crumbled house-made pork chorizo and warm flour tortillas.",
        badge: "Cheesy",
        tags: ["Savory"]
      },
      {
        id: "so-8",
        name: "Orbit Churros con Dulce de Leche",
        category: "Desserts",
        price: 9.00,
        calories: "380 kcal",
        image: "https://images.unsplash.com/photo-1624353365286-3f8d62daad51?auto=format&fit=crop&w=600&q=80",
        description: "Crispy star-shaped fried pastries rolled in cinnamon sugar, served with warm spiced Mexican chocolate and dulce de leche.",
        badge: "Sweet Crunch",
        tags: ["Dessert", "Vegetarian"]
      },
      {
        id: "so-9",
        name: "Tres Leches Andromeda Cake",
        category: "Desserts",
        price: 9.50,
        calories: "410 kcal",
        image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80",
        description: "Decadent sponge cake soaked in three varieties of sweet milk, topped with toasted meringue and fresh strawberries.",
        badge: "Silky Sweet",
        tags: ["Dessert"]
      },
      {
        id: "so-10",
        name: "Solaris Hibiscus Agave Margarita",
        category: "Beverages",
        price: 13.50,
        calories: "170 kcal",
        image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
        description: "100% Blue Agave Blanco Tequila, fresh lime, ruby hibiscus flower reduction, and volcanic black sea salt rim.",
        badge: "Signature",
        tags: ["Cocktail"]
      },
      {
        id: "so-11",
        name: "Cinnamon Rice Horchata Artesanal",
        category: "Beverages",
        price: 5.00,
        calories: "160 kcal",
        image: "https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=600&q=80",
        description: "Traditional sweet rice milk flavored with Mexican canela cinnamon quills and Madagascar vanilla, served icy cold.",
        badge: "Refreshing",
        tags: ["Non-Alcoholic", "Vegan"]
      },
      {
        id: "so-12",
        name: "Jarritos Mandarin Cosmic Soda",
        category: "Beverages",
        price: 4.50,
        calories: "130 kcal",
        image: "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=600&q=80",
        description: "Classic imported glass bottle Mexican fruit soda sweetened with 100% natural cane sugar.",
        badge: "Ice Cold",
        tags: ["Soda"]
      }
    ],
    reviews: [
      {
        user: "Sofia Rodriguez",
        rating: 5,
        date: "Yesterday",
        comment: "The Birria Quesatacos are completely out of this world! The consommé is so rich and deep. Specialist Mateo really brought authentic home flavors to the space station.",
        verified: true
      },
      {
        user: "Lucas Vance",
        rating: 5,
        date: "4 days ago",
        comment: "Best tacos in the quadrant. Fast 18-minute delivery and the churros were still crunchy and warm. 5 stars all day!",
        verified: true
      },
      {
        user: "Chef Gabriel Dupont",
        rating: 4,
        date: "1 week ago",
        comment: "Margaritas are properly balanced and the salsa verde has real fire. Great service and transparent order tracking.",
        verified: true
      }
    ]
  },
  {
    id: "celestial",
    name: "Celestial Sweet Lab & Café",
    tagline: "Stardust Patisserie, Nitrogen Gelato & Zero-G Specialty Brews",
    cuisine: "Pastry, Desserts & Specialty Café",
    rating: 4.98,
    reviewCount: 624,
    deliveryTime: "15-20 min",
    priceRange: "$$",
    bannerImage: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1400&q=80",
    themeColor: "#ec4899",
    badge: "World Pastry Champion",
    contact: {
      phone: "+1 (800) 555-SWEET",
      hotline: "+1 (888) 782-7522 (STAR-CAFE)",
      email: "starlight@celestialsweet.space",
      address: "Observatory Promenade 3, Solar Dome, Artemis Base",
      hours: "07:00 AM - 10:00 PM UTC"
    },
    astronaut: {
      name: "Flight Engineer Zara 'Starlight' Moon",
      role: "Orbital Life Support Biochemist & Master Patissier",
      rank: "Lieutenant (Canadian Space Agency / NASA)",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=600&q=80",
      quote: "Sugar crystallization and chocolate tempering under microgravity create the smoothest textures imaginable. It's chemistry made pure joy.",
      missions: "Artemis V Lunar Habitat, Orbital Chemistry Lab 3",
      specialty: "Liquid Nitrogen Cloud Gelato & Mirror-Glazed Galaxy Spheres",
      commsChannel: "EHF 38.200 GHz (Patisserie Quantum Link)"
    },
    dishes: [
      {
        id: "ce-1",
        name: "Galaxy Mirror-Glazed Mousse Sphere",
        category: "Desserts",
        price: 14.50,
        calories: "380 kcal",
        image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80",
        description: "Dark Valrhona chocolate mousse globe with a molten passionfruit-mango heart, hand-swirled with swirling violet, indigo, and stardust mirror glaze.",
        badge: "Viral Sensation",
        tags: ["Signature", "Gluten-Free"]
      },
      {
        id: "ce-2",
        name: "Liquid Nitrogen Nebula Gelato",
        category: "Desserts",
        price: 11.00,
        calories: "290 kcal",
        image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80",
        description: "Flash-frozen at -320°F tableside with fresh Madagascar vanilla cream, swirls of wild raspberry jam, and popping candy meteorites.",
        badge: "Flash Frozen",
        tags: ["Vegetarian"]
      },
      {
        id: "ce-3",
        name: "Aurora Pistachio Rose Croissant",
        category: "Pastries",
        price: 7.50,
        calories: "340 kcal",
        image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=600&q=80",
        description: "Double-baked flaky French butter croissant filled with Sicilian pistachio frangipane, topped with dried rose petals and crushed nuts.",
        badge: "Fresh Baked",
        tags: ["Pastry", "Popular"]
      },
      {
        id: "ce-4",
        name: "Orbital Macaron Constellation (Box of 6)",
        category: "Pastries",
        price: 18.00,
        calories: "480 kcal",
        image: "https://images.unsplash.com/photo-1569864321347-1904d9c7bb0b?auto=format&fit=crop&w=600&q=80",
        description: "Delicate Parisian macarons in cosmic flavors: Salted Caramel Comet, Lavender Honey Moon, Dark Cosmic Truffle, Matcha Solar, and Yuzu Meteor.",
        badge: "Gift Box",
        tags: ["Gluten-Free"]
      },
      {
        id: "ce-5",
        name: "Golden Stardust Crème Brûlée",
        category: "Desserts",
        price: 10.50,
        calories: "360 kcal",
        image: "https://images.unsplash.com/photo-1470124182917-cc6e71b22ecc?auto=format&fit=crop&w=600&q=80",
        description: "Rich baked Tahitian vanilla custard beneath a shatteringly crisp caramelized sugar crust dusted with edible lunar gold flakes.",
        badge: "Classic",
        tags: ["Vegetarian"]
      },
      {
        id: "ce-6",
        name: "Zero-G Raspberry Mille-Feuille",
        category: "Pastries",
        price: 12.00,
        calories: "410 kcal",
        image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",
        description: "Crisp caramelized puff pastry layers sandwiched with silky diplomat cream and organic tart raspberries.",
        badge: "French Classic",
        tags: ["Pastry"]
      },
      {
        id: "ce-7",
        name: "Blue Supergiant Blueberry Danish",
        category: "Pastries",
        price: 6.50,
        calories: "280 kcal",
        image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",
        description: "Flaky laminated pastry cradling rich cream cheese and spiced wild blueberry compote.",
        badge: "Morning Favorite",
        tags: ["Warm"]
      },
      {
        id: "ce-8",
        name: "Cosmic Lavender Stardust Latte",
        category: "Beverages",
        price: 6.50,
        calories: "170 kcal",
        image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=600&q=80",
        description: "Espresso combined with French culinary lavender infusion, oat milk microfoam, and purple butterfly pea dust art.",
        badge: "House Specialty",
        tags: ["Coffee", "Artisan"]
      },
      {
        id: "ce-9",
        name: "Zero-G Cold Brew Nitro Float",
        category: "Beverages",
        price: 7.50,
        calories: "220 kcal",
        image: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=600&q=80",
        description: "Single-origin Ethiopian nitro cold brew topped with a generous scoop of artisanal salted caramel stardust gelato.",
        badge: "Signature",
        tags: ["Coffee"]
      },
      {
        id: "ce-10",
        name: "Sparkling Unicorn Solar Fizz",
        category: "Beverages",
        price: 6.00,
        calories: "110 kcal",
        image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80",
        description: "Fizzy dragonfruit puree, lemonade, sparkling water, and edible holographic shimmer that swirls when stirred.",
        badge: "Magical",
        tags: ["Non-Alcoholic"]
      },
      {
        id: "ce-11",
        name: "Belgian Hot Chocolate with Cloud Marshmallow",
        category: "Beverages",
        price: 6.50,
        calories: "320 kcal",
        image: "https://images.unsplash.com/photo-1542990253-0d0f5be5f0ed?auto=format&fit=crop&w=600&q=80",
        description: "Thick 70% melted dark chocolate steamed with whole milk, crowned with a giant torch-toasted vanilla bean marshmallow.",
        badge: "Cozy Hug",
        tags: ["Warm"]
      },
      {
        id: "ce-12",
        name: "Solar Flare Tarte Tatin",
        category: "Desserts",
        price: 11.50,
        calories: "350 kcal",
        image: "https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=600&q=80",
        description: "Upside-down caramelized Granny Smith apples on buttery puff pastry, served with crème fraîche.",
        badge: "Delicate",
        tags: ["Dessert"]
      }
    ],
    reviews: [
      {
        user: "Chloe Beauchamp",
        rating: 5,
        date: "Today",
        comment: "The Galaxy mirror glaze sphere is practically art. I didn't want to break it, but once I tasted the passionfruit and dark chocolate mousse, I was in heaven!",
        verified: true
      },
      {
        user: "Lt. Daniel Foster",
        rating: 5,
        date: "3 days ago",
        comment: "Zara Moon's nitro float is my daily ritual before going on EVA patrols. Perfect sweetness and smooth coffee kick.",
        verified: true
      },
      {
        user: "Aisha Al-Mansoor",
        rating: 5,
        date: "1 week ago",
        comment: "The macarons arrived in a temperature-controlled cosmic box. Crisp shells, heavenly ganache, zero breakage. Customer support answered my questions instantly.",
        verified: true
      }
    ]
  }
];

// Helper functions for easy querying
function getRestaurantById(id) {
  return RESTAURANTS_DATA.find(r => r.id === id) || RESTAURANTS_DATA[0];
}

function getAllRestaurants() {
  return RESTAURANTS_DATA;
}
