// Main Portal Logic for CosmoBites (index.html)

document.addEventListener("DOMContentLoaded", () => {
  renderRestaurants(RESTAURANTS_DATA);
});

function renderRestaurants(restaurants) {
  const grid = document.getElementById("restaurantsGrid");
  if (!grid) return;

  if (restaurants.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: var(--text-muted);">
        <span style="font-size: 3rem;">🔭</span>
        <h3 style="color: #fff; margin-top: 10px;">No Orbiting Kitchens Found</h3>
        <p>Try searching for a different dish, cuisine, or astronaut chef.</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = restaurants.map(rest => `
    <div class="restaurant-card glass">
      <div class="card-image-wrap">
        <img src="${rest.bannerImage}" alt="${rest.name}" loading="lazy">
        <div class="badge-overlay">
          <span>🏆</span> ${rest.badge}
        </div>
        <div class="rating-badge">
          <span>★</span> ${rest.rating.toFixed(1)}
          <small style="color: #94a3b8; font-weight: normal;">(${rest.reviewCount})</small>
        </div>
      </div>

      <div class="card-body">
        <div class="card-meta-row">
          <span class="card-cuisine">${rest.cuisine}</span>
          <span>•</span>
          <span>${rest.priceRange}</span>
          <span>•</span>
          <span>⏱️ ${rest.deliveryTime}</span>
        </div>

        <h3 class="card-title">${rest.name}</h3>
        <p class="card-tagline">${rest.tagline}</p>

        <div class="astronaut-mini-profile">
          <img src="${rest.astronaut.avatar}" alt="${rest.astronaut.name}" class="astro-avatar">
          <div class="astro-mini-info">
            <div class="astro-mini-title">${rest.astronaut.role.split('&')[0]}</div>
            <div class="astro-mini-name">${rest.astronaut.name}</div>
            <div class="astro-mini-contact">
              <span>📞</span> ${rest.contact.phone}
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="info-stat">
            <span class="info-stat-label">Dishes Available</span>
            <span class="info-stat-val">${rest.dishes.length}+ Delicacies</span>
          </div>

          <a href="restaurant.html?id=${rest.id}" target="_blank" class="btn btn-primary btn-sm">
            <span>Explore Menu & Order</span> ➔
          </a>
        </div>
      </div>
    </div>
  `).join("");
}

function handleSearch() {
  const searchInput = document.getElementById("restaurantSearch");
  if (!searchInput) return;

  const query = searchInput.value.toLowerCase().trim();

  const filtered = RESTAURANTS_DATA.filter(rest => {
    const matchName = rest.name.toLowerCase().includes(query);
    const matchCuisine = rest.cuisine.toLowerCase().includes(query);
    const matchAstro =
      rest.astronaut.name.toLowerCase().includes(query) ||
      rest.astronaut.role.toLowerCase().includes(query);
    const matchDish = rest.dishes.some(dish =>
      dish.name.toLowerCase().includes(query) ||
      dish.description.toLowerCase().includes(query)
    );

    return matchName || matchCuisine || matchAstro || matchDish;
  });

  renderRestaurants(filtered);
}

function filterCuisine(cuisine, buttonElement) {
  const chips = document.querySelectorAll("#categoryChips .filter-chip");
  chips.forEach(chip => chip.classList.remove("active"));
  buttonElement.classList.add("active");

  const searchInput = document.getElementById("restaurantSearch");
  if (searchInput) searchInput.value = "";

  if (cuisine === "all") {
    renderRestaurants(RESTAURANTS_DATA);
  } else {
    const filtered = RESTAURANTS_DATA.filter(rest =>
      rest.cuisine.toLowerCase().includes(cuisine.toLowerCase())
    );
    renderRestaurants(filtered);
  }
}

function openSupportModal() {
  const modal = document.getElementById("supportModal");
  if (modal) modal.classList.add("active");
}

function closeSupportModal() {
  const modal = document.getElementById("supportModal");
  if (modal) modal.classList.remove("active");
}

function handleChatEnter(event) {
  if (event.key === "Enter") {
    sendChatMessage();
  }
}

function sendChatMessage() {
  const input = document.getElementById("chatInput");
  const messagesContainer = document.getElementById("supportChatMessages");

  if (!input || !messagesContainer) return;

  const text = input.value.trim();
  if (!text) return;

  const userBubble = document.createElement("div");
  userBubble.className = "chat-bubble user";
  userBubble.innerText = text;

  messagesContainer.appendChild(userBubble);
  input.value = "";
  messagesContainer.scrollTop = messagesContainer.scrollHeight;

  setTimeout(() => {
    const botBubble = document.createElement("div");
    botBubble.className = "chat-bubble bot";

    const lower = text.toLowerCase();

    if (lower.includes("delivery") || lower.includes("time") || lower.includes("fast")) {
      botBubble.innerText =
        "🚀 Our zero-gravity thermal delivery pods average 15 to 35 minutes depending on orbital alignment. Every dish arrives piping hot and fresh!";
    } else if (
      lower.includes("phone") ||
      lower.includes("call") ||
      lower.includes("contact") ||
      lower.includes("number")
    ) {
      botBubble.innerText =
        "📞 You can reach our 24/7 central dispatch at +1 (800) 555-COSMO or contact individual restaurant chefs directly via the numbers on their page!";
    } else if (
      lower.includes("astronaut") ||
      lower.includes("chef") ||
      lower.includes("marco") ||
      lower.includes("elena") ||
      lower.includes("sato")
    ) {
      botBubble.innerText =
        "👨‍🚀 All 5 of our head chefs are veteran space specialists! For instance, Commander Marco Rossi served on Artemis III and Dr. Kenji Sato led ISS hydroponics.";
    } else if (
      lower.includes("order") ||
      lower.includes("menu") ||
      lower.includes("dish")
    ) {
      botBubble.innerText =
        "🍽️ Click on any restaurant to explore their dedicated webpage with 15 to 25+ delicious dishes, complete with add-to-cart and order review features!";
    } else {
      botBubble.innerText =
        "🛰️ Comms received loud and clear! Our orbital support dispatch is monitoring this channel. You can also reach our flight duty officer at support@cosmobites.space.";
    }

    messagesContainer.appendChild(botBubble);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }, 600);
}

function showToast(message, icon = "🚀") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    toast.style.transition = "all 0.3s ease";

    setTimeout(() => toast.remove(), 300);
  }, 3200);
}
