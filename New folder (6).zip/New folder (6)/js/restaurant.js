
let currentRestaurant = null;
let currentCart = [];
let activeCategory = "All";
let countdownInterval = null;

document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const restId = urlParams.get("id") || "apollo";

  currentRestaurant = getRestaurantById(restId);
  if (!currentRestaurant) {
    currentRestaurant = RESTAURANTS_DATA[0];
  }

  populateRestaurantDetails(currentRestaurant);

  renderDishes(currentRestaurant.dishes);

  renderReviews(currentRestaurant.reviews);

  updateCartUI();
});

function populateRestaurantDetails(rest) {
  document.title = `${rest.name} | CosmoBites`;

  document.getElementById("navRestName").innerText = rest.name;

  const heroBanner = document.getElementById("heroBanner");
  heroBanner.style.backgroundImage = `url('${rest.bannerImage}')`;

  document.getElementById("heroBadge").innerText = rest.badge;
  document.getElementById("heroCuisine").innerText = rest.cuisine;
  document.getElementById("heroName").innerText = rest.name;
  document.getElementById("heroTagline").innerText = rest.tagline;
  document.getElementById("heroRating").innerText = rest.rating.toFixed(1);
  document.getElementById("heroReviewsCount").innerText = rest.reviewCount;
  document.getElementById("heroDelivery").innerText = rest.deliveryTime;
  document.getElementById("heroPrice").innerText = rest.priceRange;
  document.getElementById("heroAddress").innerText = rest.contact.address;

  document.getElementById("astroAvatar").src = rest.astronaut.avatar;
  document.getElementById("astroRank").innerText = rest.astronaut.rank.split('(')[0].trim();
  document.getElementById("astroRole").innerText = rest.astronaut.role;
  document.getElementById("astroName").innerText = rest.astronaut.name;
  document.getElementById("astroQuote").innerText = `"${rest.astronaut.quote}"`;
  document.getElementById("astroMissions").innerText = rest.astronaut.missions;
  document.getElementById("astroSpecialty").innerText = rest.astronaut.specialty;
  document.getElementById("astroPhone").innerText = rest.contact.phone;
  document.getElementById("astroCommsFreq").innerText = rest.astronaut.commsChannel;

  document.getElementById("reviewAvgRating").innerText = rest.rating.toFixed(1);
  document.getElementById("reviewTotalNum").innerText = rest.reviewCount;

  document.getElementById("supportAstroAvatar").src = rest.astronaut.avatar;
  document.getElementById("supportAstroName").innerText = rest.astronaut.name;
  document.getElementById("supportAstroPhone").innerText = rest.contact.phone;
  document.getElementById("supportEmergencyPhone").innerText = rest.contact.hotline;
  document.getElementById("welcomeBotMessage").innerText = 
    `Greetings Commander! I am Chef ${rest.astronaut.name}'s flight comms assistant at ${rest.name}. How can we tailor your orbital meal today?`;

  document.getElementById("footerRestName").innerText = rest.name;
  document.getElementById("allDishesCount").innerText = rest.dishes.length;
}


function renderDishes(dishes) {
  const grid = document.getElementById("dishesGrid");
  if (!grid) return;

  if (dishes.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-muted);">
        <p>No dishes match the selected filter. Try another category or search term.</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = dishes.map(dish => `
    <div class="dish-card">
      <div class="dish-image-wrap">
        <img src="${dish.image}" alt="${dish.name}" loading="lazy">
        ${dish.badge ? `<div class="dish-badge">✨ ${dish.badge}</div>` : ''}
      </div>

      <div class="dish-content">
        <div class="dish-header-row">
          <div class="dish-title">${dish.name}</div>
          <div class="dish-price">$${dish.price.toFixed(2)}</div>
        </div>

        <p class="dish-desc">${dish.description}</p>

        <div class="dish-tags">
          ${dish.tags ? dish.tags.map(tag => `<span class="dish-tag">${tag}</span>`).join('') : ''}
        </div>

        <div class="dish-footer">
          <span class="dish-cals">⚡ ${dish.calories || '450 kcal'}</span>
          <button class="btn btn-primary btn-sm" onclick="addToCart('${dish.id}')">
            <span>+ Add to Order</span>
          </button>
        </div>
      </div>
    </div>
  `).join("");
}


function filterMenuCategory(category, buttonElement) {
  activeCategory = category;
  const buttons = document.querySelectorAll("#menuTabs .menu-tab-btn");
  buttons.forEach(btn => btn.classList.remove("active"));
  buttonElement.classList.add("active");

  const searchInput = document.getElementById("menuSearchInput");
  if (searchInput) searchInput.value = "";

  if (category === "All") {
    renderDishes(currentRestaurant.dishes);
  } else {
    const filtered = currentRestaurant.dishes.filter(d => 
      d.category.toLowerCase().includes(category.toLowerCase())
    );
    renderDishes(filtered);
  }
}


function handleMenuSearch() {
  const query = document.getElementById("menuSearchInput").value.toLowerCase().trim();

  const filtered = currentRestaurant.dishes.filter(dish => {
    const matchCat = activeCategory === "All" || dish.category.toLowerCase().includes(activeCategory.toLowerCase());
    const matchQuery = dish.name.toLowerCase().includes(query) || 
                       dish.description.toLowerCase().includes(query) ||
                       (dish.tags && dish.tags.some(t => t.toLowerCase().includes(query)));
    return matchCat && matchQuery;
  });

  renderDishes(filtered);
}


function highlightMenu() {
  const section = document.getElementById("menuSection");
  if (section) {
    section.scrollIntoView({ behavior: 'smooth' });
    showToast("Orbital Menu Loaded! 15-25+ dishes ready to explore.", "📖");
  }
}


function addToCart(dishId) {
  const dish = currentRestaurant.dishes.find(d => d.id === dishId);
  if (!dish) return;

  const existing = currentCart.find(item => item.dishId === dishId);
  if (existing) {
    existing.qty += 1;
  } else {
    currentCart.push({
      dishId: dish.id,
      name: dish.name,
      price: dish.price,
      image: dish.image,
      qty: 1
    });
  }

  updateCartUI();
  showToast(`Added ${dish.name} to order tray!`, "🛸");
}

function updateCartQty(dishId, change) {
  const item = currentCart.find(i => i.dishId === dishId);
  if (!item) return;

  item.qty += change;
  if (item.qty <= 0) {
    currentCart = currentCart.filter(i => i.dishId !== dishId);
  }

  updateCartUI();
}

function updateCartUI() {
  const badge = document.getElementById("cartCountBadge");
  const quickTotal = document.getElementById("quickCartTotal");
  const cartContainer = document.getElementById("cartItemsContainer");
  const orderDetails = document.getElementById("orderDetailsSection");
  const subtotalEl = document.getElementById("cartSubtotal");
  const grandTotalEl = document.getElementById("cartGrandTotal");
  const checkoutBtn = document.getElementById("checkoutBtn");

  const totalItems = currentCart.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = currentCart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const deliveryFee = totalItems > 0 ? 2.99 : 0.00;
  const grandTotal = subtotal + deliveryFee;

  if (badge) badge.innerText = totalItems;
  if (quickTotal) quickTotal.innerText = `$${subtotal.toFixed(2)}`;

  if (subtotalEl) subtotalEl.innerText = `$${subtotal.toFixed(2)}`;
  if (grandTotalEl) grandTotalEl.innerText = `$${grandTotal.toFixed(2)}`;

  if (!cartContainer) return;

  if (currentCart.length === 0) {
    cartContainer.innerHTML = `
      <div class="cart-empty-state">
        <span style="font-size: 3.5rem;">🛸</span>
        <h4 style="color: #fff; margin: 12px 0 6px;">Your Order Tray is Empty</h4>
        <p style="font-size: 0.88rem;">Explore the menu above and add chef-crafted astronaut dishes to begin your feast.</p>
      </div>
    `;
    if (orderDetails) orderDetails.style.display = "none";
    if (checkoutBtn) {
      checkoutBtn.disabled = true;
      checkoutBtn.style.opacity = "0.5";
      checkoutBtn.innerText = "Add Dishes to Order";
    }
  } else {
    cartContainer.innerHTML = `
      <div class="cart-items-list">
        ${currentCart.map(item => `
          <div class="cart-item">
            <img src="${item.image}" alt="${item.name}" style="width: 44px; height: 44px; border-radius: 8px; object-fit: cover;">
            <div class="cart-item-info">
              <div class="cart-item-name">${item.name}</div>
              <div class="cart-item-price">$${(item.price * item.qty).toFixed(2)} ($${item.price.toFixed(2)} ea)</div>
            </div>
            <div class="cart-qty-ctrl">
              <button class="btn-qty" onclick="updateCartQty('${item.dishId}', -1)">-</button>
              <span style="font-weight: 700; font-size: 0.9rem; min-width: 18px; text-align: center;">${item.qty}</span>
              <button class="btn-qty" onclick="updateCartQty('${item.dishId}', 1)">+</button>
            </div>
          </div>
        `).join("")}
      </div>
    `;
    if (orderDetails) orderDetails.style.display = "block";
    if (checkoutBtn) {
      checkoutBtn.disabled = false;
      checkoutBtn.style.opacity = "1";
      checkoutBtn.innerHTML = `<span>🚀</span> Dispatch Order ($${grandTotal.toFixed(2)})`;
    }
  }
}

function toggleCartDrawer() {
  const backdrop = document.getElementById("cartDrawerBackdrop");
  if (backdrop) {
    backdrop.classList.toggle("active");
  }
}

function handleDrawerBackdrop(e) {
  if (e.target.id === "cartDrawerBackdrop") {
    toggleCartDrawer();
  }
}

function processOrderCheckout() {
  if (currentCart.length === 0) return;

  const custName = document.getElementById("orderCustName").value.trim() || "Astronaut Explorer";
  const custPhone = document.getElementById("orderCustPhone").value.trim() || "+1 (555) 019-9482";
  const custAddress = document.getElementById("orderCustAddress").value.trim() || "Habitat Sector Alpha";
  const custNotes = document.getElementById("orderCustNotes").value.trim() || "Standard zero-G heating.";
  const orderSpeed = document.getElementById("orderSpeed").value;

  const orderId = `CMD-${Math.floor(1000 + Math.random() * 9000)}-${currentRestaurant.id.toUpperCase().substring(0, 3)}`;
  const subtotal = currentCart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const deliveryPodFee = orderSpeed === "rocket" ? 4.99 : 2.99;
  const grandTotal = subtotal + deliveryPodFee;
  const etaMinutes = orderSpeed === "rocket" ? 15 : 28;

  toggleCartDrawer();

  const receipt = document.getElementById("receiptContent");
  receipt.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed rgba(255,255,255,0.2); padding-bottom: 14px; margin-bottom: 14px;">
      <div>
        <div style="font-size: 0.75rem; color: var(--accent); text-transform: uppercase; font-weight: 700;">Intergalactic Order ID</div>
        <div style="font-size: 1.3rem; font-weight: 800; color: #fff; font-family: var(--font-heading);">${orderId}</div>
      </div>
      <div style="text-align: right;">
        <div style="font-size: 0.75rem; color: #f59e0b; text-transform: uppercase; font-weight: 700;">Status</div>
        <div style="font-weight: 700; color: #10b981;">🚀 EN ROUTE</div>
      </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 0.88rem; margin-bottom: 16px;">
      <div>
        <span style="color: var(--text-dim);">Kitchen:</span><br>
        <strong style="color: #fff;">${currentRestaurant.name}</strong>
      </div>
      <div>
        <span style="color: var(--text-dim);">Executive Commander:</span><br>
        <strong style="color: #fff;">${currentRestaurant.astronaut.name}</strong>
      </div>
      <div>
        <span style="color: var(--text-dim);">Recipient:</span><br>
        <strong style="color: #fff;">${custName}</strong> (${custPhone})
      </div>
      <div>
        <span style="color: var(--text-dim);">Destination:</span><br>
        <strong style="color: #fff;">${custAddress}</strong>
      </div>
    </div>

    <div style="background: rgba(0,0,0,0.3); border-radius: 10px; padding: 12px; margin-bottom: 14px; font-size: 0.85rem;">
      <div style="font-weight: 700; color: #cbd5e1; margin-bottom: 6px;">Order Tray Summary:</div>
      ${currentCart.map(i => `
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span>${i.qty}x ${i.name}</span>
          <span style="color: var(--accent);">$${(i.price * i.qty).toFixed(2)}</span>
        </div>
      `).join("")}
      <div style="border-top: 1px dashed rgba(255,255,255,0.15); margin-top: 6px; padding-top: 6px; display: flex; justify-content: space-between; font-weight: 800; color: #fff;">
        <span>Total Paid:</span>
        <span style="color: #f59e0b;">$${grandTotal.toFixed(2)}</span>
      </div>
    </div>

    <!-- Countdown arrival timer -->
    <div style="text-align: center; padding: 10px; background: rgba(99, 102, 241, 0.15); border-radius: 10px; border: 1px solid rgba(99,102,241,0.3);">
      <div style="font-size: 0.78rem; color: #c7d2fe; text-transform: uppercase; font-weight: 700;">Thermal Pod Estimated Arrival:</div>
      <div id="liveCountdownTimer" style="font-size: 1.8rem; font-weight: 900; color: #fff; font-family: monospace; margin: 4px 0;">${etaMinutes}:00</div>
      <div style="font-size: 0.75rem; color: var(--text-muted);">Special Instructions: "${custNotes}"</div>
    </div>

    <div style="margin-top: 14px; font-size: 0.8rem; color: #94a3b8; font-style: italic; text-align: center;">
      "${currentRestaurant.astronaut.name}: Thank you for dining with us! Our orbital heat shields are active and your meal is sealed."
    </div>
  `;

startCountdown(etaMinutes * 60);

  const modal = document.getElementById("orderSuccessModal");
  if (modal) modal.classList.add("active");

  currentCart = [];
  updateCartUI();
  showToast(`Order confirmed by Commander ${currentRestaurant.astronaut.name}!`, "🎉");
}

function startCountdown(totalSeconds) {
  if (countdownInterval) clearInterval(countdownInterval);

  countdownInterval = setInterval(() => {
    totalSeconds -= 1;
    if (totalSeconds <= 0) {
      clearInterval(countdownInterval);
      const timerEl = document.getElementById("liveCountdownTimer");
      if (timerEl) timerEl.innerText = "DOCKED & DELIVERED! 🛎️";
      return;
    }

    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    const formatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    const timerEl = document.getElementById("liveCountdownTimer");
    if (timerEl) timerEl.innerText = formatted;
  }, 1000);
}

function closeSuccessModal() {
  const modal = document.getElementById("orderSuccessModal");
  if (modal) modal.classList.remove("active");
}


function renderReviews(reviews) {
  const list = document.getElementById("reviewsList");
  if (!list) return;

  list.innerHTML = reviews.map(rev => `
    <div class="review-item">
      <div class="review-author-row">
        <div>
          <span class="author-name">${rev.user}</span>
          ${rev.verified ? '<span style="font-size: 0.75rem; color: var(--accent); margin-left: 6px;">✓ Verified Station Crew</span>' : ''}
        </div>
        <div class="review-stars">${'★'.repeat(rev.rating)}${'☆'.repeat(5 - rev.rating)}</div>
      </div>
      <p class="review-text">"${rev.comment}"</p>
      <div style="font-size: 0.75rem; color: var(--text-dim); margin-top: 10px;">Posted ${rev.date}</div>
    </div>
  `).join("");
}

function submitReview(e) {
  e.preventDefault();
  const nameInput = document.getElementById("reviewerName");
  const ratingInput = document.getElementById("reviewerRating");
  const commentInput = document.getElementById("reviewerComment");

  const name = nameInput.value.trim();
  const rating = parseInt(ratingInput.value, 10);
  const comment = commentInput.value.trim();

  if (!name || !comment) return;

  const newReview = {
    user: name,
    rating: rating,
    date: "Just now",
    comment: comment,
    verified: true
  };

  currentRestaurant.reviews.unshift(newReview);
  currentRestaurant.reviewCount += 1;

  const avg = currentRestaurant.reviews.reduce((acc, r) => acc + r.rating, 0) / currentRestaurant.reviews.length;
  currentRestaurant.rating = Math.round(avg * 10) / 10;
  renderReviews(currentRestaurant.reviews);
  document.getElementById("reviewAvgRating").innerText = currentRestaurant.rating.toFixed(1);
  document.getElementById("reviewTotalNum").innerText = currentRestaurant.reviewCount;
  document.getElementById("heroRating").innerText = currentRestaurant.rating.toFixed(1);
  document.getElementById("heroReviewsCount").innerText = currentRestaurant.reviewCount;
  nameInput.value = "";
  commentInput.value = "";

  showToast("Your review has been broadcasted to the galaxy!", "⭐");
}


function openSupportModal() {
  const modal = document.getElementById("supportModal");
  if (modal) modal.classList.add("active");
}

function closeSupportModal() {
  const modal = document.getElementById("supportModal");
  if (modal) modal.classList.remove("active");
}

function openAstroComms() {
  openSupportModal();
}

function handleRestChatEnter(e) {
  if (e.key === "Enter") {
    sendRestChatMessage();
  }
}

function sendRestChatMessage() {
  const input = document.getElementById("restChatInput");
  const messagesContainer = document.getElementById("restaurantChatMessages");
  if (!input || !messagesContainer) return;

  const text = input.value.trim();
  if (!text) return;

  const userBubble = document.createElement("div");
  userBubble.className = "chat-bubble user";
  userBubble.innerText = text;
  messagesContainer.appendChild(userBubble);
  input.value = "";
  messagesContainer.scrollTop = messagesContainer.scrollHeight;

  setTimeout(() => {
    const botBubble = document.createElement("div");
    botBubble.className = "chat-bubble bot";

    const lower = text.toLowerCase();
    if (lower.includes("phone") || lower.includes("call") || lower.includes("contact")) {
      botBubble.innerText = `📞 You can speak directly to Chef ${currentRestaurant.astronaut.name}'s station bridge at ${currentRestaurant.contact.phone} or emergency line ${currentRestaurant.contact.hotline}.`;
    } else if (lower.includes("allerg") || lower.includes("gluten") || lower.includes("nut") || lower.includes("veg")) {
      botBubble.innerText = `🥗 Dietary Alert noted! We have dedicated zero-cross-contamination clean pods. Leave a note during checkout and Chef ${currentRestaurant.astronaut.name} will personally inspect your tray!`;
    } else if (lower.includes("menu") || lower.includes("recommend") || lower.includes("signature")) {
      botBubble.innerText = `⭐ Chef ${currentRestaurant.astronaut.name} personally recommends trying "${currentRestaurant.dishes[0].name}". It's our highest-rated specialty!`;
    } else if (lower.includes("time") || lower.includes("delivery") || lower.includes("speed")) {
      botBubble.innerText = `🚀 Average delivery to your habitat is ${currentRestaurant.deliveryTime}. You can also select Warp Rocket Express during checkout for 15-minute priority dispatch.`;
    } else {
      botBubble.innerText = `🛰️ [Station Comms]: Chef ${currentRestaurant.astronaut.name} acknowledged: "Transmission received loud and clear! Our team is standing by to prepare your feast."`;
    }

    messagesContainer.appendChild(botBubble);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }, 600);
}


function showToast(message, icon = "🚀") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}
